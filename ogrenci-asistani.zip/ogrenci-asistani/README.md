# Fırat Öğrenci Asistanı

FastAPI backend + yerel LLM (Ollama) ile yönetmelik, kulüp, hoca, ulaşım ve menü asistanı.

## Çalıştırma
```powershell
cd backend
python -m venv venv
venv\Scripts\Activate.ps1
pip install -r requirements.txt
uvicorn main:app --host 0.0.0.0 --port 8000
```
Dokümantasyon: http://localhost:8000/docs

## Endpointler
- POST /api/ask
- POST /api/advisor
- POST /api/clubs
- GET  /api/menu/today
- GET  /api/transport/yurtlar
- GET  /api/transport?yurt=...&nereye=...
- GET  /health
